# The-Monthly-News
This is the monthly news
it is at 
https://agoodman-prog.github.io/The-Monthly-News/
